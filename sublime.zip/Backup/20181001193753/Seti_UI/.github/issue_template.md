> What version of ST are you using? (nothing lower than 3103).

...

> Have you restarted ST after you installed the theme?

...

> If you still have bad render, have you removed the cache folder (found right next to the packages folder)?

...

> Extra Info "attaching a screen shot would be very helpful"

...
